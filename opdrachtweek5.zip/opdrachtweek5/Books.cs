using System;

namespace opdrachtweek5
{
   public class Book
    {
        private string name;
        private double price;
        private Author author;

        // 1. B
        private List<Author> authors;

        private int qtyInStock = 0;
    }

    public Book(string name, Author author, double price) 
    {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public static print() {
        Console.WriteLine("book: {0}, {1}", this.name, this.author, this.price)
    }

    public double getPrint() {

    }

}