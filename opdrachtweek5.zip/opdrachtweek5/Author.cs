using System;

namespace opdrachtweek5
{
   public class Author
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

/* 
public Author
{
    private string name;
    private string email;
    private char gender;
} */